# Bike_Sharing

# Project Name: Bike Sharing Assignment
> Outline a brief description of your project.
Its required to model the demand for shared bikes with the available independent variables. It will be used by the management to understand how exactly the demands vary with different features and can accordingly manipulate the business strategy to meet the demand levels and meet the customer's expectations. Further, the model will be a good way for management to understand the demand dynamics of a new market. 






## Conclusions
- temp: A coefficient value of ‘0.5636’ indicated that a unit increase in temp variable, increases the bike hire numbers by 0.5636 units.
- linear relation between temp and atemp variable with the predictor ‘cnt’.

Training dataset R^2:  0.8034340217318539
Testing dataset R^2 0.7697103361601403
Testing adjusted dataset R^2 0.7598407791384321
Adj. R-squared:	0.800 from lr7.summary()




## libraries  Used
numpy 
pandas
matplotlib.pyplot 
seaborn
sklearn



## Acknowledgements

- This project was on as part of UPGRAD Assignment (https://learn.upgrad.com/).


## Contact
Created by [@NikhitaS17] - feel free to contact me!



