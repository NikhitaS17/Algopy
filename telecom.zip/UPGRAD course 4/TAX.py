# Income tax calculation for India (considering 2023-2024 tax slabs and rates)

# Basic Salary (provided)
basic_salary = 295080

# Gross Salary (provided)
gross_salary = 1002432

# Investment under section 80C (provided)
section_80c_investment = 150000

# Education Loan Deduction (provided)
education_loan_deduction = 100000

# City (provided)
city = "Bengaluru"

# HRA Limit Calculation (based on city type)
if city.lower() == "metro":
    hra_limit = 0.5 * basic_salary
else:
    hra_limit = 0.4 * basic_salary

# Actual HRA Received (provided)
actual_hra = 147000

# Rent Paid
rent_paid = 99000

# Calculating HRA Exemption (considering lowest among options)
hra_exemption = min(actual_hra, hra_limit, rent_paid - 0.1 * basic_salary)

# Taxable Income Calculation
taxable_income = gross_salary - section_80c_investment - hra_exemption - education_loan_deduction

# Tax Slabs (assuming 2023-2024)
tax_slabs = [250000, 500000, 750000]
tax_rates = [0, 0.05, 0.20]

# Tax Calculation (considering applicable tax slab)
tax_liability = 0
for i in range(len(tax_slabs)):
    if taxable_income <= tax_slabs[i]:
        tax_liability = (taxable_income * tax_rates[i]) / 100
        break
    else:
        taxable_income -= tax_slabs[i]
        tax_liability += (tax_slabs[i] * tax_rates[i]) / 100

# Adding surcharge and cess (assuming no rebate)
surcharge_cess = 0  # Replace with actual surcharge and cess calculation if applicable

total_tax_liability = tax_liability + surcharge_cess

print("Taxable Income:", taxable_income)
print("Estimated Tax Liability:", total_tax_liability)